## Activity 22: Wireframing Solved

## Explanation and Result

* We started with our header and sub-heading already defined which leaves us with the body and footer to complete.

* We move down our page to create three elements on the same row.

* When we move onto the coding phase of this mini-project you will note that we will be placing these three elements into a container. This container will determine how our elements sit on the row of our web page.

* Inside of our row that is highlighted in red, we see a blue highlighted box which determines how elements sit on the column.

* The container which holds our column acts similar to our row container but on the opposite axis.

* We repeat the steps above to create the next row of our website.

* Finally, we reached the footer of our website which is simply a blocked off area at the bottom of the page.

![Finished wireframe of the Module 02 mini-project](./assets/Images/01-wireframe-form-completed.png)

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
